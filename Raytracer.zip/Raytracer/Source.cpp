#include <stdio.h>


void main(int argc, char **argv)
{
	getchar();

}